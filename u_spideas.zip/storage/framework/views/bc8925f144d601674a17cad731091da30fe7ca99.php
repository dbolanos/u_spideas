<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-12">
                <?php if($message = Session::get('message')): ?>
                    <div class="alert alert-<?php echo e($message['type_message']); ?>" role="alert">
                        <?php echo $message['msg']; ?>

                        <button type="button" class="close" data-dismiss="alert" areia-label="Close"><span aria-hidden="true">&times;</span></button>
                    </div>
                <?php endif; ?>
                <div class="card">
                    <div class="card-header">Solicitudes</div>
                    <div class="card-body">
                        <div class="form-group row">
                            <?php if(count($requests) > 0): ?>
                                <table class="table table-condensed">
                                    <thead>
                                    <tr>
                                        <th>Alumno</th>
                                        <th>Infraestructura</th>
                                        <th>Evento</th>
                                        <th>Periodo</th>
                                        <th>Estado</th>
                                        <th>Acciones</th>
                                    </tr>
                                    </thead>
                                    <tbody>
                                    <?php $__currentLoopData = $requests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $request): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($request->student->getFullName()); ?></td>
                                            <td><?php echo e($request->infrastructure->description); ?></td>
                                            <td><?php echo e($request->event->description); ?></td>
                                            <td><?php echo e($request->period->description); ?></td>
                                            <td><?php echo e($request->requestStatus->description); ?></td>
                                            <td>
                                                <a href="<?php echo e(route('edit.request', ['id' => $request->id])); ?>" class="btn btn-success" ><i class="fas fa-edit"></i></a>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                                <div class="row">
                                    <div class="col-md-12 text-center">
                                        <?php echo e($requests->links()); ?>

                                    </div>
                                </div>
                            <?php else: ?>
                                <div class="alert alert-warning">
                                    No se ha encuentrado ninguna solicitud
                                </div>
                            <?php endif; ?>

                        </div>
                    </div>
                    <div class="card-footer">
                        <div class="form-group row">
                          <a href="<?php echo e(route('create.request')); ?>" class="btn btn-primary btn-icon-split btn-user ">
                            <span class="icon text-white-50">
                              <i class="fas fa-plus-square"></i>
                            </span>
                            <span class="text">Crear Solicitud</span>
                          </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /* C:\xampp\htdocs\u_spideas\resources\views/admin/request/index.blade.php */ ?>