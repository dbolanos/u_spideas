<?php echo $__env->make('partials.headerGuest', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('partials.topbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="container">

    <div class="card o-hidden border-0 shadow-lg my-5">
      <div class="card-body p-0">
        <!-- Nested Row within Card Body -->
        <div class="row">
          <div class="col-lg-5 d-none d-lg-block">
            <img src="<?php echo e(url('/img/deas.png')); ?>" alt="" style="width:100%; height:100%">
          </div>
          <div class="col-lg-7">
            <div class="p-5">
              <div class="text-center">
                <h1 class="h4 text-gray-900 mb-4">Crear una cuenta</h1>
              </div>
              <form class="user" method="POST" action="<?php echo e(route('register')); ?>" id="register">
                <?php echo csrf_field(); ?>
                <div class="form-group row">
                  <div class="col-sm-6 mb-3 mb-sm-0">
                    <input type="text" class="form-control <?php echo e($errors->has('first_name') ? ' is-invalid' : ''); ?> form-control-user"
                    id="first_name" name="first_name" placeholder="Nombre" value="<?php echo e(old('first_name')); ?>" required>

                    <?php if($errors->has('first_name')): ?>
                      <span class="invalid-feedback" role="alert">
                        <strong><?php echo e($errors->first('first_name')); ?></strong>
                      </span>
                    <?php endif; ?>
                  </div>

                  <div class="col-sm-6">
                    <input type="text" class="form-control form-control-user <?php echo e($errors->has('identification_card') ? ' is-invalid' : ''); ?>"
                    id="identification_card" name="identification_card" placeholder="Cédula" value="<?php echo e(old('identification_card')); ?>" required>

                    <?php if($errors->has('identification_card')): ?>
                      <span class="invalid-feedback" role="alert">
                          <strong><?php echo e($errors->first('identification_card')); ?></strong>
                      </span>
                    <?php endif; ?>
                  </div>
                </div>

                <div class="form-group row">
                  <div class="col-sm-6 mb-3 mb-sm-0">
                    <input type="text" class="form-control form-control-user <?php echo e($errors->has('first_surname') ? ' is-invalid' : ''); ?>"
                    id="first_surname" name="first_surname" placeholder="Primer Apellido" value="<?php echo e(old('first_surname')); ?>" required>

                    <?php if($errors->has('first_surname')): ?>
                      <span class="invalid-feedback" role="alert">
                          <strong><?php echo e($errors->first('first_surname')); ?></strong>
                      </span>
                    <?php endif; ?>
                  </div>

                  <div class="col-sm-6">
                    <input type="text" class="form-control form-control-user <?php echo e($errors->has('second_surname') ? ' is-invalid' : ''); ?>"
                    id="second_surname" name="second_surname" placeholder="Segundo Apellido" value="<?php echo e(old('second_surname')); ?>" required>

                    <?php if($errors->has('second_surname')): ?>
                      <span class="invalid-feedback" role="alert">
                          <strong><?php echo e($errors->first('second_surname')); ?></strong>
                      </span>
                    <?php endif; ?>
                  </div>
                </div>

                <div class="form-group">
                  <input type="email" class="form-control form-control-user <?php echo e($errors->has('email') ? ' is-invalid' : ''); ?>"
                  id="email" name="email" placeholder="Email" value="<?php echo e(old('email')); ?>" required>

                  <?php if($errors->has('email')): ?>
                      <span class="invalid-feedback" role="alert">
                          <strong><?php echo e($errors->first('email')); ?></strong>
                      </span>
                  <?php endif; ?>
                </div>

                <div class="form-group row">
                  <div class="col-sm-6 mb-3 mb-sm-0">
                    <input type="password" class="form-control form-control-user form-control<?php echo e($errors->has('password') ? ' is-invalid' : ''); ?>"
                    id="password" name="password" placeholder="Contraseña" required>

                    <?php if($errors->has('password')): ?>
                        <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($errors->first('password')); ?></strong>
                        </span>
                    <?php endif; ?>
                  </div>
                  <div class="col-sm-6">
                    <input type="password" class="form-control form-control-user" id="password-confirm"
                    name="password-confirm" placeholder="Confirmar Contraseña" required>
                  </div>
                </div>
                <a href="<?php echo e(route('register')); ?>" class="btn btn-primary btn-user btn-block"
                onclick="document.getElementById('register').submit();">
                  Registrarse
                </a>
              </form>
              <hr>
              <div class="text-center">
                <a class="small" href="<?php echo e(route('login')); ?>">Ya posee una cuenta?</a>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>

</div>






<?php echo $__env->make('partials.footerGuestMain', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php /* C:\xampp\htdocs\u_spideas\resources\views/auth/register.blade.php */ ?>