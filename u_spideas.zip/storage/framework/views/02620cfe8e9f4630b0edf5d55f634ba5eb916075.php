<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <?php if($message = Session::get('message')): ?>
                    <div class="alert alert-<?php echo e($message['type_message']); ?>" role="alert">
                        <?php echo $message['msg']; ?>

                        <button type="button" class="close" data-dismiss="alert" areia-label="Close"><span aria-hidden="true">&times;</span></button>
                    </div>
                <?php endif; ?>
                <div class="card">
                    <div class="card-header">Eventos</div>
                    <div class="card-body">
                        <div class="form-group row">
                            <?php if(count($events) > 0): ?>
                                <table class="table table-condensed">
                                    <thead>
                                    <tr>
                                        <th>Id</th>
                                        <th>Description</th>
                                        <th>Acciones</th>
                                    </tr>
                                    </thead>
                                    <tbody>
                                    <?php $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($event->id); ?></td>
                                            <td><?php echo e($event->description); ?></td>
                                            <td>
                                                <a href="<?php echo e(route('edit.event', ['id' => $event->id])); ?>" class="btn btn-success"> Editar <i class="fas fa-edit"></i></a>
                                                <a href="<?php echo e(route('delete.event', ['id' => $event->id])); ?>" class="btn btn-danger"> Borrar <i class="fas fa-trash-alt"></i></a>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                                <div class="row">
                                    <div class="col-md-12 text-center">
                                        <?php echo e($events->links()); ?>

                                    </div>
                                </div>
                            <?php else: ?>
                                <div class="alert alert-warning">
                                    No se ha encontrado ningún evento
                                </div>
                            <?php endif; ?>

                        </div>
                    </div>
                    <div class="card-footer">
                        <div class="form-group row">
                            <a href="<?php echo e(route('create.event')); ?>" class="btn btn-primary pull-right"> Crear Evento <i class="fas fa-plus-square"></i></a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /* C:\xampp\htdocs\u_spideas\resources\views/admin/events/index.blade.php */ ?>