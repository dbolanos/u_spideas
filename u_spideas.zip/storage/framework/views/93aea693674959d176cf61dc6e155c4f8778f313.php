<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">Reporte</div>
                    <div class="card-body">
                        <div class="form-group row">
                            <label for="descrip_event" class="col-md-4 col-form-label text-md-right">Cantidad de Estudiantes <i class="fas fa-user-graduate"></i> </label>
                            <div class="col-md-8">
                                <h3># <span class="badge badge-success"><?php echo e($result['count_students']); ?></span></h3>
                            </div>
                        </div>
                        <hr>
                        <div class="form-group row">
                            <label for="descrip_event" class="col-md-4 col-form-label text-md-right">Cantidad Solicitudes <i class="fas fa-boxes"></i> </label>
                            <div class="col-md-8">
                                <h3># <span class="badge badge-primary"><?php echo e($result['count_request']); ?></span></h3>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="descrip_event" class="col-md-4 col-form-label text-md-right">Solicitudes en estado Pendientes <i class="far fa-pause-circle"></i> </label>
                                <h3># <span class="badge badge-secondary"><?php echo e($result['count_request_pending']); ?></span></h3>
                            <label for="descrip_event" class="col-md-4 col-form-label text-md-right">Solicitudes en estado Aprobado <i class="fas fa-thumbs-up"></i> </label>
                                <h3># <span class="badge badge-secondary"><?php echo e($result['count_request_approved']); ?></span></h3>
                            <label for="descrip_event" class="col-md-4 col-form-label text-md-right">Solicitudes en estado Terminado <i class="fas fa-check-double"></i> </label>
                                <h3># <span class="badge badge-secondary"><?php echo e($result['count_request_finish']); ?></span></h3>
                            <label for="descrip_event" class="col-md-4 col-form-label text-md-right">Solicitudes en estado Bloqueado <i class="fas fa-stop-circle"></i> </label>
                                <h3># <span class="badge badge-secondary"><?php echo e($result['count_request_block']); ?></span></h3>
                        </div>

                        <hr>

                        <h4>Eventos: <span class="badge badge-secondary"><?php echo e(count($result['events'])); ?></span></h4>
                        <div class="col-md-8">

                            <table class="table table-condensed">
                                <thead>
                                <tr>
                                    <th>Id</th>
                                    <th>Description</th>
                                </tr>
                                </thead>
                                <tbody>
                                <?php $__currentLoopData = $result['events']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($event->id); ?></td>
                                        <td><?php echo e($event->description); ?></td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>

                        <hr>

                        <h4>Infraestructura: <span class="badge badge-secondary"><?php echo e(count($result['infrastructure'])); ?></span></h4> </label>
                        <div class="col-md-8">
                            <table class="table table-condensed">
                                <thead>
                                <tr>
                                    <th>Id</th>
                                    <th>Description</th>
                                </tr>
                                </thead>
                                <tbody>
                                <?php $__currentLoopData = $result['infrastructure']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $infrastructure): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($infrastructure->id); ?></td>
                                        <td><?php echo e($infrastructure->description); ?></td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /* C:\xampp\htdocs\u_spideas\resources\views/admin/report/report.blade.php */ ?>