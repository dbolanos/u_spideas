<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <?php if($message = Session::get('message')): ?>
                    <div class="alert alert-<?php echo e($message['type_message']); ?>" role="alert">
                        <?php echo $message['msg']; ?>

                        <button type="button" class="close" data-dismiss="alert" areia-label="Close"><span aria-hidden="true">&times;</span></button>
                    </div>
                <?php endif; ?>
                <div class="card">
                    <div class="card-header">Infraestructuras</div>
                    <div class="card-body">
                        <div class="form-group row">
                            <?php if(count($infrastructures) > 0): ?>
                                <table class="table table-condensed">
                                    <thead>
                                    <tr>
                                        <th>Id</th>
                                        <th>Description</th>
                                        <th>Acciones</th>
                                    </tr>
                                    </thead>
                                    <tbody>
                                    <?php $__currentLoopData = $infrastructures; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $infrastructure): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($infrastructure->id); ?></td>
                                            <td><?php echo e($infrastructure->description); ?></td>
                                            <td>
                                              <a href="<?php echo e(route('edit.infrastructure', ['id' => $infrastructure->id])); ?>"
                                                class="btn btn-info btn-icon-split btn-user ">
                                                <span class="icon text-white-50">
                                                  <i class="fas fa-edit"></i>
                                                </span>
                                                <span class="text">Editar</span>
                                              </a>
                                              <a href="<?php echo e(route('delete.infrastructure', ['id' => $infrastructure->id])); ?>"
                                                class="btn btn-danger btn-icon-split btn-user ">
                                                <span class="icon text-white-50">
                                                  <i class="fas fa-trash-alt"></i>
                                                </span>
                                                <span class="text">Eliminar</span>
                                              </a>

                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                                <div class="row">
                                    <div class="col-md-12 text-center">
                                        <?php echo e($infrastructures->links()); ?>

                                    </div>
                                </div>
                            <?php else: ?>
                                <div class="alert alert-warning">
                                    No se ha encontrado ninguna infraestructura
                                </div>
                            <?php endif; ?>

                        </div>
                    </div>
                    <div class="card-footer">
                        <div class="form-group row">
                          <a href="<?php echo e(route('create.infrastructure')); ?>" class="btn btn-primary btn-icon-split btn-user ">
                            <span class="icon text-white-50">
                              <i class="fas fa-plus-square"></i>
                            </span>
                            <span class="text">Agregar Infraestructura</span>
                          </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /* C:\xampp\htdocs\u_spideas\resources\views/admin/infrastructures/index.blade.php */ ?>