<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header">Editar Infraestructura</div>
                    <div class="card-body">
                        <form action="<?php echo e(route('update.infrastructure')); ?>" method="POST" id="editar">
                            <?php echo csrf_field(); ?>
                            <input type="hidden" name="infrastructure_id" value="<?php echo e($infrastructure->id); ?>">
                            <div class="form-group row">
                                <label for="descrip_infra" class="col-md-4 col-form-label text-md-right">Descripcion Infraestructura </label>
                                <div class="col-md-8">
                                    <input name="descrip_infra" type="text" id="descrip_infra" value="<?php echo e($infrastructure->description); ?>">

                                    <?php if($errors->has('descrip_infra')): ?>
                                        <span class="alert alert-danger" role="alert">
                                        <strong><?php echo e($errors->first('descrip_infra')); ?></strong>
                                    </span>
                                    <?php endif; ?>
                                </div>
                            </div>
                              <a href="" class="btn btn-primary btn-icon-split btn-user "
                              onclick="document.getElementById('editar').submit();">
                                <span class="icon text-white-50">
                                  <i class="fas fa-arrow-circle-right"></i>
                                </span>
                                <span class="text">Actualizar</span>
                              </a>

                            <!--<button type="submit" class="btn btn-primary"> Actualizar <i class="fas fa-undo"></i></button>-->
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /* C:\xampp\htdocs\u_spideas\resources\views/admin/infrastructures/edit.blade.php */ ?>