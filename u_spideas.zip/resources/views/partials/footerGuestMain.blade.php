<!-- start footer Area -->
<footer class="sticky-footer bg-gray-700 text-gray-100">
  <div class="container my-auto text-gray-100">
    <div class="copyright text-center my-auto text-gray-100">
      <span class=""><b class="text-gray-100">Copyright &copy; CAF Projects 2019</b></span>
    </div>
  </div>
</footer>
<!-- End footer Area -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<!-- Latest compiled and minified JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
{{--<script src="js/vendor/bootstrap.min.js"></script>--}}
<script type="text/javascript" src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBhOdIF3Y9382fqJYt5I_sswSrEw5eihAA"></script>
<script src="js/superfish.min.js"></script>
<script src="js/jquery.magnific-popup.min.js"></script>
<script src="js/main.js"></script>
<script src="{{ asset('js/sb-admin-2.js')}}"></script>
<script src="{{ asset('js/sb-admin-2.min.js')}}"></script>
</body>
</html>
